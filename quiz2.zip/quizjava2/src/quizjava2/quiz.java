package quizjava2;

import javax.swing.JOptionPane;

import java.util.Scanner;

public class quiz {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner leer = new Scanner(System.in);
		int opcion = 0;
		
		int resultado;
		
			System.out.println("seleccione una opcion");
			System.out.println("1. Numero mayor");
	           System.out.println("2. Numero Menor");
	           System.out.println("3. Raiz Cuadrada");
	           System.out.println("4. Elevar una potencia");
	           System.out.println("5. Salir ");
	           opcion = leer.nextInt();
	           switch (opcion) {
	   		case 1:
	   			numeromayor();
	   			break;
	   		case 2:
	   			numeromenor();
	   			break;
	   		case 3: 
	   			raiz();
	   			break;
	   		case 4:
	   			elevar();
	   			break;
	   		case 5:
	   			salir();
	   			
	   			
	   		}

	   	}
	                   		
		
		public static void numeromayor(){
			Scanner leer = new Scanner(System.in);
			 System.out.println("Ingrese el numero a");
			 int num1 = leer.nextInt();
			
			 System.out.println("Ingrese el numero b");
			  int num2= leer.nextInt();
			System.out.println("El mayor de los dos números es " + Math.max(num1, num2));
		}

		public static void numeromenor(){
			Scanner leer = new Scanner(System.in);
			System.out.println("Ingrese el numero a");
			 int num1 = leer.nextInt();
			
			 System.out.println("Ingrese el numero b");
			  int num2= leer.nextInt();
			System.out.println("El mayor de los dos números es " + Math.min(num1, num2));	
			
		}
		public static void raiz(){
			Scanner leer = new Scanner(System.in);
			 System.out.println("Ingrese el numero ");
			 int num1 = leer.nextInt();
			double resultado = Math.sqrt(num1);
	        System.out.println("La raíz cuadrada de " + num1 + " es " + resultado);    
		
			
		}
		public static void elevar(){
			Scanner leer = new Scanner(System.in);
			System.out.println("Ingrese el numero");
			 int num1 = leer.nextInt();
			
			 System.out.println("A cuanto quieres elevarlo");
			  int num2= leer.nextInt();
			double resultado = Math.pow(num1, num2);
			System.out.println("su potencia da" + resultado);
		}
		public static void salir(){
			System.out.println("hasta luego");
	}
			
		}
		

	        	   



